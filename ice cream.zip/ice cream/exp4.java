import java.util.Scanner;
abstract class shape{
      int x=2,y=12;
      void printArea(){

      }
}
class Rectangle extends shape{
    
    void printArea(){
    System.out.println("THE RECTANGLE AREA:"+x*y);
    }
}
class Circle extends shape{
    
    void printArea(){
    System.out.println("THE RECTANGLE AREA:"+(3.14*x));
    }
}
class Triangle extends shape{
    
    void printArea(){
    System.out.println("THE RECTANGLE AREA:"+(1/2*x*y));
    }
}
class exp4{
    public static void main(String[] args) {
        Rectangle rec=new Rectangle();
        Circle cir=new Circle();
        Triangle tri=new Triangle();
        rec.printAre();
        cir.printAre();
        tri.printAre();
    }
}